package com.example.kotinrecord.base

import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.viewbinding.ViewBinding
import java.io.Serializable
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.ParameterizedType

abstract class BaseBindingFragment<T : ViewBinding> : Fragment() {
    protected lateinit var viewBinder: T


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val type = javaClass.genericSuperclass
        val actualTypeArguments = (type as ParameterizedType).actualTypeArguments
        val tClass = actualTypeArguments[0] as Class<T>
        val method = tClass.getMethod(
            "inflate",
            LayoutInflater::class.java,
            ViewGroup::class.java,
            Boolean::class.javaPrimitiveType
        )
        viewBinder = method.invoke(null, inflater, container, false) as T

        viewBinder.initListener()
        viewBinder.initData()
        return viewBinder.root
    }

    fun <T : Activity> startActivity(tClass: Class<T>?, key: String, value: Serializable) {
        val intent = Intent(requireContext(), tClass)
        intent.putExtra(key, value)
        startActivity(intent)
    }

    protected abstract fun T.initData()
    interface IntentApply {
        fun apply(intent: Intent?)
    }

    protected fun <T : Activity?> startActivity(
        tClass: Class<T>,
        intentApply: BaseBindingActivity.IntentApply? = null
    ) {
        val intent = Intent(activity, tClass)
        intentApply?.apply(intent)
        startActivity(intent)
    }


    fun <T : Activity?> startActivityForResult(
        tClass: Class<T>?,
        intentApply: BaseBindingActivity.IntentApply? = null,
        requestCode: Int
    ) {
        val intent = Intent(activity, tClass)
        intentApply?.apply(intent)
        startActivityForResult(intent, requestCode)
    }


    protected abstract fun T.initListener()
    protected fun toast(msg: String) {
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
    }
}