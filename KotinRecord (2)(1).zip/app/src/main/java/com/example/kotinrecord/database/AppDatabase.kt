package com.example.kotinrecord.database

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.kotinrecord.bean.Account
import com.example.kotinrecord.bean.User


@Database(
    entities = [Account::class, User::class],
    version = 1, exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var database: AppDatabase? = null

        @JvmStatic
        fun Context.getDatabase(): AppDatabase {
            return database ?: synchronized(this) {
                val databaseX =
                    Room.databaseBuilder(this.applicationContext, AppDatabase::class.java, "app_db")
                        .allowMainThreadQueries()
                        .build()
                database = databaseX
                databaseX
            }
        }

        @JvmStatic
        fun Fragment.getDatabase(): AppDatabase {
            return this.requireContext().getDatabase()
        }
    }
}
