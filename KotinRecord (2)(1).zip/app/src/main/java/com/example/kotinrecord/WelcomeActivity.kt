package com.example.kotinrecord

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import com.example.kotinrecord.R
import com.example.kotinrecord.base.BaseBindingActivity
import com.example.kotinrecord.databinding.ActivityWelcomeBinding

class WelcomeActivity : BaseBindingActivity<ActivityWelcomeBinding>() {
    override fun ActivityWelcomeBinding.initListener() {

    }


    override fun ActivityWelcomeBinding.initData() {
        viewBinder.tvName.append(intent.getStringExtra("username") ?: "")
        var index = 3
        val handler = object : Handler(Looper.getMainLooper()) {
            @SuppressLint("SetTextI18n")
            override fun handleMessage(msg: Message) {
                super.handleMessage(msg)
                if (isDestroyed || isFinishing) {
                    return
                }
                sendEmptyMessageDelayed(1, 1000)
                tvGo.text = "立即进入（${--index}）"
                if (index == 0) {
                    removeMessages(1)
                    startActivity<LoginActivity>()
                    finish()
                }
            }
        }
        handler.sendEmptyMessageDelayed(1, 1000)
        tvGo.setOnClickListener {
            startActivity<MainActivity>()
            finish()
        }
    }

}