package com.example.kotinrecord.base

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.viewbinding.ViewBinding

abstract class BindAdapter<VB : ViewBinding, Data> : RecyclerView.Adapter<BindHolder<VB>>() {
    val data: ArrayList<Data> = ArrayList()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BindHolder<VB> {
        return BindHolder(parent.createHolder())
    }

    abstract fun ViewGroup.createHolder(): VB
    override fun onBindViewHolder(holder: BindHolder<VB>, position: Int) {
        val d = data[position]
        holder.vb.bind(d, position)
    }

    abstract fun VB.bind(data: Data, position: Int)
    override fun getItemCount(): Int {
        return data.size
    }

    fun addData(newData: List<Data>) {
        data.clear()
        data.addAll(newData)
        notifyDataSetChanged()
    }

    fun addOneData(newData: Data) {
        data.add(newData)
        notifyDataSetChanged()
    }

    fun removeOneData(newData: Data) {
        data.remove(newData)
        notifyItemRemoved(data.indexOf(newData))
    }

    fun isEmpty() = data.isEmpty()
}