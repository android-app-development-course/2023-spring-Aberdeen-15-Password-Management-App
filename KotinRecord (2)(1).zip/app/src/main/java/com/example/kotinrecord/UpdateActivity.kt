package com.example.kotinrecord

import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import com.example.kotinrecord.base.BaseBindingActivity
import com.example.kotinrecord.bean.Account
import com.example.kotinrecord.bean.Platform
import com.example.kotinrecord.database.AppDatabase.Companion.getDatabase
import com.example.kotinrecord.databinding.ActivityUpdateBinding
import com.google.android.material.navigation.NavigationBarView.OnItemSelectedListener

class UpdateActivity : BaseBindingActivity<ActivityUpdateBinding>() {
    override fun ActivityUpdateBinding.initListener() {
        tvSave.setOnClickListener {
            val accountStr = etAccount.text.toString()
            val password = etPassword.text.toString()
            val remark = etRemark.text.toString()
            val platform = spinner.selectedItem.toString()
            if (accountStr.isEmpty() || password.isEmpty() || remark.isEmpty()) {
                return@setOnClickListener
            }
            if (account != null) {
                getDatabase().appDao()
                    .updateAccount(Account(accountStr, password, platform, remark, account!!.id))
                finish()
            } else {
                getDatabase().appDao()
                    .addAccount(Account(accountStr, password, platform, remark))
                finish()
            }
        }
    }

    private var account: Account? = null
    override fun ActivityUpdateBinding.initData() {
        spinner.adapter = ArrayAdapter(
            this@UpdateActivity,
            android.R.layout.simple_spinner_dropdown_item,
            Platform.platform
        )
        account = intent.getSerializableExtra("account") as Account?
        account?.let {
            etAccount.setText(it.account)
            etPassword.setText(it.password)
            etRemark.setText(it.remark)
            spinner.setSelection(Platform.indexOf(it.platform))
            tvTitle.text = "编辑"
        }
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                (view as TextView).setTextColor(getColor(R.color.colorPrimary))
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }

    }

}