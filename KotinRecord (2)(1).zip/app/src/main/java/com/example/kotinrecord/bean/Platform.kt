package com.example.kotinrecord.bean

import com.example.kotinrecord.R

data class Platform(val name: String, val image: Int):java.io.Serializable {
    companion object {
        val platform = arrayListOf(
            Platform("微信", R.drawable.wx),
            Platform("QQ", R.drawable.qq),
            Platform("微博", R.drawable.wb),
            Platform("百度", R.drawable.bd),
            Platform("支付宝", R.drawable.zfb)
        )

        fun indexOf(name: String): Int {
            for (platform in platform.withIndex()) {
                if (name == platform.value.name) {
                    return platform.index
                }
            }
            return 0;
        }
    }

    override fun toString() = name
}