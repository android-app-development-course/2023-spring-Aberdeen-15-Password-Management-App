package com.example.kotinrecord


import android.view.ViewGroup
import com.example.kotinrecord.base.BaseBindingActivity
import com.example.kotinrecord.base.BindAdapter
import com.example.kotinrecord.bean.Platform
import com.example.kotinrecord.databinding.ActivityMainBinding
import com.example.kotinrecord.databinding.ItemPlatformBinding


class MainActivity : BaseBindingActivity<ActivityMainBinding>() {

    private val adapter = object : BindAdapter<ItemPlatformBinding, Platform>() {
        override fun ViewGroup.createHolder() =
            ItemPlatformBinding.inflate(layoutInflater, this, false)

        override fun ItemPlatformBinding.bind(data: Platform, position: Int) {
            tvName.text = data.name
            ivMusic.setImageResource(data.image)
            root.setOnClickListener {
                startActivity<AccountListActivity>("platform", data)
            }
        }
    }


    override fun ActivityMainBinding.initListener() {
        tvAdd.setOnClickListener {
            startActivity<UpdateActivity>()
        }
    }

    override fun ActivityMainBinding.initData() {
        adapter.addData(Platform.platform)
        viewBinder.rvPlatform.adapter = adapter
    }
}