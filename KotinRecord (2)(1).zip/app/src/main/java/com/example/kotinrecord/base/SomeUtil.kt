package com.example.kotinrecord.base

import android.content.res.Resources
import android.util.DisplayMetrics
import android.view.View
import android.widget.ImageView
import com.bumptech.glide.Glide
import java.text.SimpleDateFormat
import java.util.*

object SomeUtil {
    fun Date.yyyyMMdd(): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(this)
    fun Date.yyyyMMddHHmmss(): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(this)
    fun Long.yyyyMMdd() = Date(this).yyyyMMdd()
    fun Long.yyyyMMddHHmmss() = Date(this).yyyyMMddHHmmss()

}