package com.example.kotinrecord.base

import androidx.recyclerview.widget.RecyclerView
import androidx.viewbinding.ViewBinding

class BindHolder<VB : ViewBinding>(val vb: VB) : RecyclerView.ViewHolder(vb.root)