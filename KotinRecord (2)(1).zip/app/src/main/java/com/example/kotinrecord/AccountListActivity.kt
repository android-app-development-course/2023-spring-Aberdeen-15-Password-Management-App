package com.example.kotinrecord

import android.annotation.SuppressLint
import android.content.res.Resources
import android.util.TypedValue
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams
import com.example.kotinrecord.base.BaseBindingActivity
import com.example.kotinrecord.base.BindAdapter
import com.example.kotinrecord.bean.Account
import com.example.kotinrecord.bean.Platform
import com.example.kotinrecord.database.AppDatabase.Companion.getDatabase
import com.example.kotinrecord.databinding.ActivityAccountListBinding
import com.example.kotinrecord.databinding.ItemAccountBinding
import com.google.android.material.snackbar.Snackbar
import com.yanzhenjie.recyclerview.SwipeMenuItem

private val Int.dp: Int
    get() {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            this.toFloat(),
            Resources.getSystem().displayMetrics
        ).toInt()
    }

class AccountListActivity : BaseBindingActivity<ActivityAccountListBinding>() {
    private val adapter = object : BindAdapter<ItemAccountBinding, Account>() {
        override fun ViewGroup.createHolder() =
            ItemAccountBinding.inflate(layoutInflater, this, false)

        @SuppressLint("SetTextI18n")
        override fun ItemAccountBinding.bind(data: Account, position: Int) {
            tvAccount.text = "账号：${data.account}"
            tvRemark.text = "备注：${data.remark}"
            if (data.visibility) {
                tvPassword.text = "密码：${data.password}"
            } else {
                tvPassword.text = "密码：******"
            }
            tvPassword.setOnClickListener {
                data.visibility = !data.visibility
                notifyItemChanged(position)
            }
        }
    }

    override fun ActivityAccountListBinding.initListener() {

    }

    private lateinit var platform: Platform
    override fun ActivityAccountListBinding.initData() {
        platform = intent.getSerializableExtra("platform") as Platform
        tvTitle.text = platform.name
        ivIcon.setImageResource(platform.image)
        rvAccount.setSwipeMenuCreator { _, rightMenu, _ ->
            rightMenu.addMenuItem(SwipeMenuItem(this@AccountListActivity).apply {
                setImage(R.drawable.ic_baseline_edit_24)
                text = "编辑"
                height = LayoutParams.MATCH_PARENT
                width = 60.dp
                setBackgroundColor(getColor(R.color.colorPrimary))
            })
            rightMenu.addMenuItem(SwipeMenuItem(this@AccountListActivity).apply {
                setImage(R.drawable.ic_baseline_delete_24)
                text = "删除"
                height = LayoutParams.MATCH_PARENT
                width = 60.dp
                setBackgroundColor(getColor(R.color.red))
            })
        }
        rvAccount.setOnItemMenuClickListener { menuBridge, adapterPosition ->
            val newData = adapter.data[adapterPosition]
            if (menuBridge.position == 0) {
                startActivity<UpdateActivity>("account", newData)
                menuBridge.closeMenu()
            } else {
                adapter.removeOneData(newData)
                getDatabase().appDao().deleteAccount(newData)
                Snackbar.make(window.decorView, "删除成功", Snackbar.LENGTH_SHORT)
                    .setAction("撤销") {
                        getDatabase().appDao().addAccount(newData)
                        adapter.data.add(adapterPosition, newData)
                        adapter.notifyItemInserted(adapterPosition)
                    }.show()
            }
        }
        rvAccount.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        adapter.addData(
            getDatabase().appDao()
                .getAccount(platform.name)
        )
    }
}