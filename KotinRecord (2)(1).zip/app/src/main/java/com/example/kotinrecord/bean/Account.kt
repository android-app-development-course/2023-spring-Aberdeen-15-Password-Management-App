package com.example.kotinrecord.bean

import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.PrimaryKey

@Entity
data class Account(
    val account: String,
    val password: String,
    val platform: String,
    val remark: String,
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

) : java.io.Serializable {
    @Ignore
    var visibility: Boolean = false
}
