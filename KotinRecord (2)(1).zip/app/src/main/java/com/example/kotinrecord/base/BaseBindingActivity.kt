package com.example.kotinrecord.base

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.viewbinding.ViewBinding
import java.io.Serializable
import java.lang.reflect.ParameterizedType

abstract class BaseBindingActivity<T : ViewBinding> : AppCompatActivity() {
    protected lateinit var viewBinder: T
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val type = javaClass.genericSuperclass
        val actualTypeArguments = (type as ParameterizedType).actualTypeArguments
        val tClass = actualTypeArguments[0] as Class<T>
        val method = tClass.getMethod("inflate", LayoutInflater::class.java)
        viewBinder = method.invoke(null, layoutInflater) as T
        setContentView(viewBinder.root)
        viewBinder.initData()
        viewBinder.initListener()
//        val backBtn = findViewById<View>(R.id.backBtn)
//        backBtn?.setOnClickListener { finish() }
    }


    interface IntentApply {
        fun apply(intent: Intent)
    }

    inline fun <reified T : Activity> startActivity(intentApply: IntentApply? = null) {
        val intent = Intent(this, T::class.java)
        intentApply?.apply(intent)
        startActivity(intent)
    }


    inline fun <reified T : Activity> startActivity(key: String, value: Serializable?) {
        val intent = Intent(this, T::class.java)
        intent.putExtra(key, value)
        startActivity(intent)
    }

    inline fun <reified T : Activity> startActivityForResult(activityResultCallback: ActivityResultCallback<ActivityResult>) {
        registerForActivityResult(
            ActivityResultContracts.StartActivityForResult(),
            activityResultCallback
        ).launch(Intent(this, T::class.java))
    }


    protected abstract fun T.initListener()
    protected abstract fun T.initData()
    protected fun toast(msg: String?) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

}