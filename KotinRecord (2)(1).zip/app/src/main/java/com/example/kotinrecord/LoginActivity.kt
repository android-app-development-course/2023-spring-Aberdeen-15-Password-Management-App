package com.example.kotinrecord

import android.app.Activity
import android.content.Intent
import androidx.activity.result.contract.ActivityResultContracts
import com.example.kotinrecord.base.BaseBindingActivity
import com.example.kotinrecord.database.AppDatabase.Companion.getDatabase
import com.example.kotinrecord.databinding.ActivityLoginBinding

class LoginActivity : BaseBindingActivity<ActivityLoginBinding>() {
    override fun ActivityLoginBinding.initListener() {
        val launcher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult(),
            ) {
            if (it.resultCode == Activity.RESULT_OK) {
                etTitle.setText(it.data?.getStringExtra("username"))
                etContent.setText(it.data?.getStringExtra("password"))
            }
        }
        tvRegister.setOnClickListener {
            launcher.launch(Intent(this@LoginActivity, RegisterActivity::class.java))
        }
        tvSave.setOnClickListener {
            val username = etTitle.text.toString()
            val password = etContent.text.toString()
            if (username.isEmpty() || password.isEmpty()) {
                return@setOnClickListener
            }
            getDatabase().appDao().apply {
                if (getUser(username, password) == null) {
                    toast("账号或密码错误")
                } else {
                    toast("登录成功")
                    startActivity<WelcomeActivity>("username",username)
                }
            }
        }
    }

    override fun ActivityLoginBinding.initData() {

    }

}