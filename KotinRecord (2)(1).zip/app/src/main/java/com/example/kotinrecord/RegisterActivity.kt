package com.example.kotinrecord

import android.content.Intent
import com.example.kotinrecord.base.BaseBindingActivity
import com.example.kotinrecord.bean.User
import com.example.kotinrecord.database.AppDatabase.Companion.getDatabase
import com.example.kotinrecord.databinding.ActivityLoginBinding
import com.example.kotinrecord.databinding.ActivityRegisterBinding

class RegisterActivity : BaseBindingActivity<ActivityRegisterBinding>() {
    override fun ActivityRegisterBinding.initListener() {
        tvSave.setOnClickListener {
            val username = etTitle.text.toString()
            val password = etContent.text.toString()
            if (username.isEmpty() || password.isEmpty()) {
                return@setOnClickListener
            }
            getDatabase().appDao().apply {
                if (getUser(username) == null) {
                    registerUser(User(username, password))
                    toast("注册成功")
                    setResult(RESULT_OK, Intent().putExtra("username",username).putExtra("password",password))
                    finish()
                } else {
                    toast("用户名已存在")
                }
            }
        }
        tvRegister.setOnClickListener {
            finish()
        }
    }

    override fun ActivityRegisterBinding.initData() {

    }

}