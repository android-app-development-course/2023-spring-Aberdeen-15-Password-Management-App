package com.example.kotinrecord.database

import androidx.room.*
import com.example.kotinrecord.bean.Account
import com.example.kotinrecord.bean.User

@Dao
interface AppDao {
    @Insert
    fun registerUser(user: User)

    @Delete
    fun deleteUser(user: User)

    @Update
    fun updateUser(user: User)

    @Query("SELECT * FROM users WHERE username = :username")
    fun getUser(username: String): User?

    @Query("SELECT * FROM users WHERE username = :username and password=:password")
    fun getUser(username: String, password: String): User?

    @Insert
    fun addAccount(account: Account)

    @Update
    fun updateAccount(account: Account)

    @Delete
    fun deleteAccount(newData: Account)

    @Query("select * from account where platform = :name")
    fun getAccount(name: String): List<Account>
}
